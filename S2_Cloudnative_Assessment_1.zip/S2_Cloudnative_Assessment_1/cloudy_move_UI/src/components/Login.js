import React, { Component }  from 'react';
import { FormGroup,FormLabel, FormControl } from 'react-bootstrap';
import { setAuthToken, setUserName } from "../sessionmanager/Session";
import "./Login.css";
import axios from 'axios';

class  Login extends Component{
    constructor(props){
        super(props);
        this.onLogin = this.onLogin.bind(this);
        this.isInputValid = this.isInputValid.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.validateUserInput = this.validateUserInput.bind(this);
        this.state = {
            userName: '',
            password: '',
            grant_type: 'password',
            token:'',
            tripsummary:[],
            errors: {
                userName: '',
                password: '',
              },
            };
            this.errorMessages = {
                userName: 'User name is not valid.',
                password: 'password is not valid.',
            };
    }
    isInputValid(fieldName){
        return this.state.errors[fieldName] === '';
    }
    handleChange(e){
        this.setState({ [e.target.name]: e.target.value });
    }
    validateUserInput(e) {
        this.setState({ [e.target.name]: e.target.value.trim() });
        const targetField = e.target.name;
        let errors = this.state.errors;
        if (!this.state[targetField]) {
          errors[targetField] = `Required field.`;
        } else {
          errors = this.validate(targetField);
        }
        this.setState({ errors });
      }
      validate(targetField) {
        const nameRegex = /^[a-zA-Z\s\-]+$/;
        let errors = this.state.errors;
        switch (targetField) {
          case 'userName':
          case 'password':
            errors[targetField] = this.state[targetField] == null ? this.errorMessages[targetField] : '';
            break;
          default:
            errors[targetField] = '';
        }
        return errors;
      }
    onLogin(){
        console.log("fetching ");
        axios({
            method: 'post',
            url: 'http://30.138.168.237:9999/oauth/token',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Authorization': 'Basic '+btoa("client:secret")
            },
            params: {
              username: this.state.userName,
              password: this.state.password,
              grant_type:this.state.grant_type
            }
          }).then(response => response.data)
            .then((data) => {
             // if (data.msg === 'active') {
               // setUserProfile(data);
              //  console.log(window.sessionStorage.getItem("userProfile"));
               // this.props.userHasAuthenticated(true);
               // this.props.history.push("/home");
            //  } else {
             //   console.log('inactive');
             // }setAuthToken
             setAuthToken(data.access_token);
             this.state.token = data.access_token;
             setUserName(this.state.username);
            /// this.props.userHasAuthenticated(true);
            /// console.log(window.sessionStorage.getItem("username"));
             this.props.history.push("/home");
             //cookies.set('username', 'this.state.username', { path: '/' });
           // cookie.save("userId",userId, expireDate);
          //  cookies.save("access_token", data.access_token,  { path: '/' });
            });
          console.log(this.state.userResponse);
        // fetch("http://vdaasw1006652.us.ad.wellpoint.com:8080/trip/")
        // .then(res => res.json)
        // .then(data => {
        //   console.log(data);
        //   this.setState({ tripSummary: data });
        //   this.props.history.push('/home');
        // })
        // .catch(console.log);

        axios({
          method: 'get',
          url: 'http://30.138.168.237:9999/cloudymove-client-api/trip/',
          headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + this.state.token
          }
      }).then(response => response.data)
          .then((data) => {
              this.setState({ tripsummary: data })
              console.log('cehek', data)
          });
    }
render(){
    return(
        <div className="loginForm">
        <form noValidate >
          <div className="row">
            <div className="col-md-4 col-sm-4">
              <FormGroup
                controlId="userNameText"
                validationState={this.state.errors['userName'] ? 'error' : null}
              >
                <FormLabel>
                  Username <span className="fieldRequired">*</span>
                </FormLabel>
                <FormControl
                  maxLength="20"
                  name="userName"
                  type="text"
                  value={this.state.userName}
                  placeholder="Enter User Name"
                  onChange={this.handleChange}
                  onBlur={e => {
                    this.validateUserInput(e);
                  }}
                />
               {!this.isInputValid('userName') && (
                  <p className="fa ant-form-item-error">
                    <span>{this.state.userName ? this.state.errors['userName'] : 'Required field'}</span>
                  </p>
                )}
              </FormGroup>
            </div>
            </div>
            <div className="row">
            <div className="col-md-4 col-sm-4">
              <FormGroup
                controlId="passwordText"
                validationState={this.state.errors['password'] ? 'error' : null}
              >
                <FormLabel>
                  Password <span className="fieldRequired">*</span>
                </FormLabel>
                <FormControl
                  maxLength="20"
                  name="password"
                  type="text"
                  value={this.state.password}
                  placeholder="Enter Password"
                  onChange={this.handleChange}
                  onBlur={e => {
                    this.validateUserInput(e);
                  }}
                />
               {!this.isInputValid('password') && (
                  <p className="fa ant-form-item-error">
                    <span>{this.state.password ? this.state.errors['password'] : 'Required field'}</span>
                  </p>
                )}
              </FormGroup>
            </div>
            </div>
            <div className="row">
            <div className="col-md-4 col-sm-4">
            <button onClick ={ e => { e.preventDefault(); this.onLogin();}}>Login</button>
            </div>
            </div>
            </form>
            {this.state.tripsummary && <TripSummary tripSummary={this.state.trips} />}
            </div>
        /*<div className="commonLoginForm">
        <form class="form-inline">
        
        <FormGroup className={this.state.errors['userName'] ? 'error' : ''}>
                <label>
                  User Name <span className="error-message">*</span>
                </label>
                <FormControl
                  maxLength="20"
                  name="userName"
                  value={this.state.userName}
                  placeholder="User name"
                  onBlur={e => {
                    this.validateUserInput(e);
                  }}
                  onChange={e => this.handleChange(e)}
                />
                {!this.isInputValid('userName') && (
                  <p className="fa ant-form-item-error">
                    <span>{this.state.userName ? this.state.errors['userName'] : 'Required field'}</span>
                  </p>
                )}
              </FormGroup>
              <br/>
              <FormGroup className={this.state.errors['password'] ? 'error' : ''}>
                <label>
                 Password<span className="error-message">*</span>
                </label>
                <FormControl
                  maxLength="20"
                  name="password"
                  value={this.state.password}
                  placeholder="Password"
                  onBlur={e => {
                    this.validateUserInput(e);
                  }}
                  onChange={e => this.handleChange(e)}
                />
                {!this.isInputValid('password') && (
                  <p className="fa ant-form-item-error">
                    <span>{this.state.password ? this.state.errors['password'] : 'Required field'}</span>
                  </p>
                )}
              </FormGroup>
</form>
</div>
<div className="commonLoginForm">
            <div className="form-row align-items-center">
              <FormGroup className={this.state.errors['userName'] ? 'error' : ''}>
                <label>
                  User Name <span className="error-message">*</span>
                </label>
                <FormControl
                  maxLength="20"
                  name="userName"
                  value={this.state.userName}
                  placeholder="User name"
                  onBlur={e => {
                    this.validateUserInput(e);
                  }}
                  onChange={e => this.handleChange(e)}
                />
                {!this.isInputValid('userName') && (
                  <p className="fa ant-form-item-error">
                    <span>{this.state.userName ? this.state.errors['userName'] : 'Required field'}</span>
                  </p>
                )}
              </FormGroup>
            </div>
            <div className="form-row align-items-center col-md-6 col-sm-12 field-section">
              <FormGroup className={this.state.errors['password'] ? 'error' : ''}>
                <label>
                 Password<span className="error-message">*</span>
                </label>
                <FormControl
                  maxLength="20"
                  name="password"
                  value={this.state.password}
                  placeholder="Password"
                  onBlur={e => {
                    this.validateUserInput(e);
                  }}
                  onChange={e => this.handleChange(e)}
                />
                {!this.isInputValid('password') && (
                  <p className="fa ant-form-item-error">
                    <span>{this.state.password ? this.state.errors['password'] : 'Required field'}</span>
                  </p>
                )}
              </FormGroup>
            </div>
            <button onClick ={ e => { e.preventDefault(); this.onLogin();}}>Login</button>
        </div> */
        
    );
}
}
 
export default Login