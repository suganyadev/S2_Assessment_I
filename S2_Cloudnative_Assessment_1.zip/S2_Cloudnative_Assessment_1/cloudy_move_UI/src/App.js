import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import Login from "./components/Login";
import Router from "./Routers/Router"

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tripSummary: []
    };
  }

  componentDidMount() {
    fetch("http://jsonplaceholder.typicode.com/users")
      .then(res => res.json)
      .then(data => {
        console.log(data);
        this.setState({ tripSummary: data });
      })
      .catch(console.log);
  }
  render() {
    return (
      <div className="App">
      <Router props ={this.state.tripSummary}/>
        <div className="App-body">
          <h5 className="App-title">
            Welcome to Cloudy Move, Travel Mamnagement System !!!{" "}
          </h5>
          <h6 className="App-subtitle mb-2 text-muted">
            Find your destination around the world !
          </h6>
          <Login />
          
        </div>
       
      </div>
    );
  }
}

export default App;
