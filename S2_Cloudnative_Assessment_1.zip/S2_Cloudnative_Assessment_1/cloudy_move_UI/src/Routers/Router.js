import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import  Login from "../components/Login";
import Home from "../components/Home";
import App from "../App";
import AppliedRoute from "./AppliedRoute";

export default ({props}) => (
  <BrowserRouter> 
  <Switch>
    <AppliedRoute path="/login" exact component={Login} />
    <AppliedRoute path="/home" exact component={Home} />
    { /* Finally, catch all unmatched routes */ }
    {/* <Route component={App} /> */}
  </Switch>
</BrowserRouter>);