package com.manage.travel.models;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

public class TripInfo {
	@Id
	public ObjectId _id;

	// ObjectId needs to be converted to string
	public String get_id() { return _id.toHexString(); }
	public void set_id(ObjectId _id) { this._id = _id; }
	public String customerName;
	public String destination;
	public String departureFrom;
	 

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDepartureFrom() {
		return departureFrom;
	}
	public void setDepartureFrom(String departureFrom) {
		this.departureFrom = departureFrom;
	}



}
