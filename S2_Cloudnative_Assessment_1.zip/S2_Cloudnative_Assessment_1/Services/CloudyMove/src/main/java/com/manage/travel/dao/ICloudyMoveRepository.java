package com.manage.travel.dao;
import com.manage.travel.models.TripInfo;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface ICloudyMoveRepository extends MongoRepository < TripInfo, String >  {

	//@Query
	//TripInfo findByCustomerId(ObjectId id);
	@Query
	List<TripInfo> findBy_id(ObjectId id);
	//List<TripInfo> findByRiderId(String userId);

	List<TripInfo> findByCustomerName(String customerName);
}
