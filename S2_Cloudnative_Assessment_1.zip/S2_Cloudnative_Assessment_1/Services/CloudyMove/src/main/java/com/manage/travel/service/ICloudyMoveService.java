package com.manage.travel.service;

public interface ICloudyMoveService {

}
