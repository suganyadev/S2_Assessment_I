package com.manage.travel.controller;

import java.util.List;

import javax.validation.Valid;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.manage.travel.dao.ICloudyMoveRepository;
import com.manage.travel.models.TripInfo;

@RestController
@RequestMapping("/trip")
public class TripSummaryController {
	@Autowired
	private ICloudyMoveRepository repository;

	@RequestMapping(value ="/", method = RequestMethod.GET)
	public List<TripInfo> getAll() {
		return repository.findAll();
	}
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public List<TripInfo> getById(@PathVariable("id") ObjectId id) {
		return repository.findBy_id(id);
	}
	@RequestMapping(value = "/customer/{name}", method = RequestMethod.GET)
	public List<TripInfo> getByName(@PathVariable("name") String customerName) {
		return repository.findByCustomerName(customerName);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public void modifyById(@PathVariable("id") ObjectId id, @Valid 
			@RequestBody TripInfo tripInfo) {
		tripInfo.set_id(id);
		repository.save(tripInfo);
	}


	@RequestMapping(value = "/", method = RequestMethod.POST)
	public TripInfo create(@Valid @RequestBody TripInfo trip) {
		trip.set_id(ObjectId.get());
		repository.save(trip);
		return trip;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void delete(@PathVariable ObjectId id) {
		//repository.delete(repository.findBy_id(id));
	}
}
