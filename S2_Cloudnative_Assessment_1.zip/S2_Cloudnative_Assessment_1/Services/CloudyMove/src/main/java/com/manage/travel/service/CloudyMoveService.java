package com.manage.travel.service;

public class CloudyMoveService implements ICloudyMoveService{

}
