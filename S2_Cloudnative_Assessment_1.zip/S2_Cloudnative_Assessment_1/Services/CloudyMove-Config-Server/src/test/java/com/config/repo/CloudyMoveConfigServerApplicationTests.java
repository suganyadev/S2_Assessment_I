package com.config.repo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudyMoveConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
