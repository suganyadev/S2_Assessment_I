package com.secure.authorization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableAutoConfiguration
@SpringBootApplication
public class CloudyMoveAuthServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudyMoveAuthServerApplication.class, args);
	}

}
