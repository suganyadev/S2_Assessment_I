package com.secure.authorization.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.secure.authorization.model.User;

public interface UserRepository extends MongoRepository<User, String> {

	User findByUserId(String userId);

}