package com.secure.authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudMoveAuthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
